# About this template

This is a template for a sketch using the p5.js library in conjunction with Microsoft Typescript.

## References

[p5.js library](https://p5js.org/)
[Typescript](https://www.typescriptlang.org/)
